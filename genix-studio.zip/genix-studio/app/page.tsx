'use client'

import { useState, useRef } from 'react'

type LogType = 'info' | 'ok' | 'warn' | 'err' | 'dim'
interface LogLine { msg: string; type: LogType }

const COLORS = ['#7c6dfa','#fa6d9e','#00e5a0','#fbbf24','#60a5fa','#f97316','#e879f9','#f43f5e']
const NICHES = [
  'Clínica Estética','Clínica Odontológica','Clínica de Psicologia','Academia & Fitness',
  'Restaurante & Gastronomia','Loja de Moda','Escritório de Advocacia','Imobiliária de Luxo',
  'Agência de Marketing','Consultoria Empresarial','Studio de Arquitetura','Outro',
]
const STYLES = ['Dark Luxury','Editorial Minimalista','Neobrutalist Bold','Organic Premium','Tech Futurista']

export default function Home() {
  const [tab, setTab] = useState<'form'|'preview'>('form')
  const [color, setColor] = useState('#7c6dfa')
  const [useGithub, setUseGithub] = useState(true)
  const [useVercel, setUseVercel] = useState(true)
  const [loading, setLoading] = useState(false)
  const [progress, setProgress] = useState(0)
  const [logs, setLogs] = useState<LogLine[]>([])
  const [code, setCode] = useState('')
  const [result, setResult] = useState<{vercelUrl?:string;repoUrl?:string}|null>(null)
  const [error, setError] = useState('')
  const logRef = useRef<HTMLDivElement>(null)

  const addLog = (msg: string, type: LogType = 'dim') => {
    setLogs(l => [...l, { msg, type }])
    setTimeout(() => { if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight }, 50)
  }

  const generate = async () => {
    setError('')
    setResult(null)
    setLogs([])
    setProgress(0)
    setCode('')

    const nome = (document.getElementById('nome') as HTMLInputElement).value.trim()
    const nicho = (document.getElementById('nicho') as HTMLSelectElement).value
    const diferencial = (document.getElementById('diferencial') as HTMLInputElement).value.trim()
    const servicos = (document.getElementById('servicos') as HTMLTextAreaElement).value.trim()
    const depoimento = (document.getElementById('depoimento') as HTMLTextAreaElement).value.trim()
    const whatsapp = (document.getElementById('whatsapp') as HTMLInputElement).value.trim()
    const estilo = (document.getElementById('estilo') as HTMLSelectElement).value

    if (!nome || !nicho || !diferencial) {
      setError('Preencha: Nome, Nicho e Diferencial.')
      return
    }

    setLoading(true)
    addLog('> Pipeline GENIX iniciado...', 'info')
    addLog(`> Cliente: ${nome} | Nicho: ${nicho}`)
    addLog(`> Estilo: ${estilo} | Cor: ${color}`)

    // Step 1: Claude
    setProgress(10)
    addLog('> [1/3] Enviando ao Claude Sonnet...', 'info')
    let generatedCode = ''
    try {
      const r = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nome, nicho, diferencial, servicos, depoimento, whatsapp, estilo, cor: color }),
      })
      const d = await r.json()
      if (!r.ok || d.error) throw new Error(d.error || 'Erro no Claude')
      generatedCode = d.code
      setCode(generatedCode)
      setProgress(35)
      addLog(`> ✓ Código gerado! (${generatedCode.length} chars)`, 'ok')
    } catch (e: any) {
      addLog('> ✗ Erro no Claude: ' + e.message, 'err')
      setError(e.message)
      setLoading(false)
      return
    }

    // Step 2: GitHub
    let repoUrl = ''
    if (useGithub) {
      setProgress(45)
      addLog('> [2/3] Criando repositório no GitHub...', 'info')
      try {
        const r = await fetch('/api/github', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ nome, code: generatedCode }),
        })
        const d = await r.json()
        if (!r.ok || d.error) throw new Error(d.error)
        repoUrl = d.repoUrl
        setProgress(60)
        addLog(`> ✓ Repositório criado: ${d.fullName}`, 'ok')
      } catch (e: any) {
        addLog('> ⚠ GitHub: ' + e.message, 'warn')
      }
    } else {
      addLog('> GitHub desabilitado.', 'dim')
    }

    // Step 3: Vercel
    let vercelUrl = ''
    if (useVercel) {
      setProgress(65)
      addLog('> [3/3] Fazendo deploy na Vercel...', 'info')
      try {
        const r = await fetch('/api/vercel-deploy', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ nome, code: generatedCode }),
        })
        const d = await r.json()
        if (!r.ok || d.error) throw new Error(d.error)
        vercelUrl = d.vercelUrl
        setProgress(95)
        addLog(`> ✓ Site publicado: ${vercelUrl}`, 'ok')
      } catch (e: any) {
        addLog('> ⚠ Vercel: ' + e.message, 'warn')
      }
    } else {
      addLog('> Vercel desabilitado.', 'dim')
    }

    setProgress(100)
    addLog('> 🎉 Pipeline concluído!', 'ok')
    setResult({ vercelUrl, repoUrl })
    setLoading(false)
  }

  const copyCode = () => {
    navigator.clipboard.writeText(code)
  }

  const logColor: Record<LogType, string> = {
    info: '#7c6dfa', ok: '#00e5a0', warn: '#fbbf24', err: '#f87171', dim: '#444'
  }

  return (
    <div style={{ position: 'relative', zIndex: 1 }}>
      {/* Background glows */}
      <div style={{
        position: 'fixed', inset: 0, pointerEvents: 'none', zIndex: 0, overflow: 'hidden'
      }}>
        <div style={{ position: 'absolute', top: '-20%', left: '-10%', width: '50%', height: '50%',
          background: 'radial-gradient(circle, rgba(124,109,250,0.12) 0%, transparent 70%)' }} />
        <div style={{ position: 'absolute', bottom: '-20%', right: '-10%', width: '50%', height: '50%',
          background: 'radial-gradient(circle, rgba(250,109,158,0.10) 0%, transparent 70%)' }} />
      </div>

      <div style={{ maxWidth: 900, margin: '0 auto', padding: '0 24px', position: 'relative', zIndex: 1 }}>

        {/* Header */}
        <header style={{ padding: '28px 0 20px', display: 'flex', alignItems: 'center',
          justifyContent: 'space-between', borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
          <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 22,
            background: 'linear-gradient(135deg, #fff 30%, #7c6dfa)',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
            GEN<span style={{ WebkitTextFillColor: '#7c6dfa' }}>IX</span>
          </div>
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 1.5, textTransform: 'uppercase',
            padding: '4px 12px', borderRadius: 100, background: 'rgba(124,109,250,0.15)',
            color: '#7c6dfa', border: '1px solid rgba(124,109,250,0.3)' }}>
            Elite AI Studio
          </div>
        </header>

        {/* Hero */}
        <div style={{ padding: '52px 0 40px', textAlign: 'center' }}>
          <h1 style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800,
            fontSize: 'clamp(28px, 5vw, 52px)', letterSpacing: -2, lineHeight: 1, marginBottom: 16 }}>
            Sites{' '}
            <span style={{ background: 'linear-gradient(135deg, #7c6dfa, #fa6d9e)',
              WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
              cinematográficos
            </span>
            {' '}em segundos
          </h1>
          <p style={{ color: 'rgba(240,240,240,0.45)', fontSize: 15, maxWidth: 480,
            margin: '0 auto', lineHeight: 1.7 }}>
            Claude gera o código · GitHub salva · Vercel publica. Tudo automático.
          </p>
        </div>

        {/* Tabs */}
        <div style={{ display: 'flex', gap: 4, background: '#0d0d0d',
          border: '1px solid rgba(255,255,255,0.08)', borderRadius: 12, padding: 4, marginBottom: 28 }}>
          {(['form','preview'] as const).map(t => (
            <button key={t} onClick={() => setTab(t)} style={{
              flex: 1, padding: '9px', background: tab === t ? '#7c6dfa' : 'transparent',
              border: 'none', borderRadius: 8, color: tab === t ? '#fff' : 'rgba(240,240,240,0.45)',
              fontSize: 12, fontWeight: 700, letterSpacing: 0.5, textTransform: 'uppercase', cursor: 'pointer',
              transition: 'all 0.2s'
            }}>
              {t === 'form' ? '🎨 Design' : '📄 Preview Código'}
            </button>
          ))}
        </div>

        {/* TAB: FORM */}
        {tab === 'form' && (
          <div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
              <Field label="Nome da Empresa *">
                <input id="nome" type="text" placeholder="Ex: Clínica Luminus" style={inputStyle} maxLength={40} />
              </Field>
              <Field label="Nicho / Segmento *">
                <select id="nicho" style={inputStyle}>
                  <option value="">Selecione...</option>
                  {NICHES.map(n => <option key={n} value={n}>{n}</option>)}
                </select>
              </Field>
              <div style={{ gridColumn: '1 / -1' }}>
                <Field label="Diferencial Principal *">
                  <input id="diferencial" type="text" style={inputStyle}
                    placeholder="Ex: Tecnologia européia + atendimento 24h" maxLength={120} />
                </Field>
              </div>
              <div style={{ gridColumn: '1 / -1' }}>
                <Field label="Serviços / Especialidades">
                  <textarea id="servicos" rows={2} style={{ ...inputStyle, resize: 'vertical' }}
                    placeholder="Ex: Botox, Preenchimento, Harmonização Facial..." />
                </Field>
              </div>
              <div style={{ gridColumn: '1 / -1' }}>
                <Field label="Depoimento de Cliente">
                  <textarea id="depoimento" rows={2} style={{ ...inputStyle, resize: 'vertical' }}
                    placeholder={`"Resultado incrível! Profissionalismo raro." — Ana Paula, SP`} />
                </Field>
              </div>
              <Field label="WhatsApp">
                <input id="whatsapp" type="text" style={inputStyle} placeholder="+55 11 99999-9999" />
              </Field>
              <Field label="Estilo Visual">
                <select id="estilo" style={inputStyle}>
                  {STYLES.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </Field>
              <div style={{ gridColumn: '1 / -1' }}>
                <Field label="Cor de Destaque">
                  <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
                    {COLORS.map(c => (
                      <div key={c} onClick={() => setColor(c)} style={{
                        width: 30, height: 30, borderRadius: 8, background: c, cursor: 'pointer',
                        border: color === c ? '2px solid #fff' : '2px solid transparent',
                        transform: color === c ? 'scale(1.15)' : 'scale(1)',
                        transition: 'all 0.15s'
                      }} />
                    ))}
                    <input type="color" value={color} onChange={e => setColor(e.target.value)}
                      style={{ width: 30, height: 30, padding: 2, background: 'transparent',
                        border: '1px solid rgba(255,255,255,0.2)', borderRadius: 8, cursor: 'pointer' }} />
                  </div>
                </Field>
              </div>
            </div>

            {/* Toggles */}
            <Toggle label="🚀 Deploy automático na Vercel" sub="Publica online após gerar"
              on={useVercel} toggle={() => setUseVercel(v => !v)} />
            <Toggle label="📦 Criar repositório no GitHub" sub="Salva o código-fonte"
              on={useGithub} toggle={() => setUseGithub(v => !v)} />

            {/* Generate button */}
            <button onClick={generate} disabled={loading} style={{
              width: '100%', padding: '15px', marginTop: 8,
              background: loading ? 'rgba(255,255,255,0.1)' : 'linear-gradient(135deg, #7c6dfa, #fa6d9e)',
              border: 'none', borderRadius: 12, color: '#fff',
              fontFamily: 'Syne, sans-serif', fontSize: 15, fontWeight: 800, cursor: loading ? 'not-allowed' : 'pointer',
              transition: 'all 0.2s', letterSpacing: 0.5
            }}>
              {loading ? '⏳ Gerando...' : '⚡ Gerar Landing Page'}
            </button>

            {/* Error */}
            {error && (
              <div style={{ marginTop: 12, padding: '12px 16px', background: 'rgba(248,113,113,0.08)',
                border: '1px solid rgba(248,113,113,0.3)', borderRadius: 10,
                fontSize: 12, color: '#f87171', lineHeight: 1.6 }}>
                ⚠️ {error}
              </div>
            )}

            {/* Progress */}
            {loading && (
              <div style={{ marginTop: 20 }}>
                <div style={{ height: 3, background: 'rgba(255,255,255,0.08)', borderRadius: 3, overflow: 'hidden', marginBottom: 12 }}>
                  <div style={{ height: '100%', width: progress + '%',
                    background: 'linear-gradient(90deg, #7c6dfa, #fa6d9e)',
                    borderRadius: 3, transition: 'width 0.5s ease' }} />
                </div>
                <div ref={logRef} style={{ background: '#000', border: '1px solid rgba(255,255,255,0.08)',
                  borderRadius: 10, padding: '12px 16px', fontFamily: 'monospace', fontSize: 11,
                  lineHeight: 1.7, maxHeight: 200, overflowY: 'auto' }}>
                  {logs.map((l, i) => (
                    <div key={i} style={{ color: logColor[l.type] }}>{l.msg}</div>
                  ))}
                </div>
              </div>
            )}

            {/* Result */}
            {result && (
              <div style={{ marginTop: 20, background: 'rgba(0,229,160,0.06)',
                border: '1px solid rgba(0,229,160,0.25)', borderRadius: 16, padding: 24, textAlign: 'center' }}>
                <div style={{ fontSize: 40, marginBottom: 10 }}>🚀</div>
                <h2 style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 22, marginBottom: 6 }}>
                  {result.vercelUrl ? 'Site no ar!' : 'Código gerado!'}
                </h2>
                <p style={{ color: 'rgba(240,240,240,0.45)', fontSize: 13, marginBottom: 20 }}>
                  {result.vercelUrl
                    ? 'Landing page publicada com sucesso.'
                    : 'Código pronto — veja na aba Preview.'}
                </p>
                <div style={{ display: 'flex', gap: 10, justifyContent: 'center', flexWrap: 'wrap' }}>
                  {result.vercelUrl && (
                    <a href={result.vercelUrl} target="_blank" rel="noreferrer" style={{
                      padding: '12px 24px', background: '#00e5a0', color: '#000',
                      borderRadius: 10, fontWeight: 700, fontSize: 13, textDecoration: 'none' }}>
                      🌐 Abrir Site
                    </a>
                  )}
                  {result.repoUrl && (
                    <a href={result.repoUrl} target="_blank" rel="noreferrer" style={{
                      padding: '12px 24px', background: 'rgba(255,255,255,0.06)',
                      border: '1px solid rgba(255,255,255,0.1)',
                      color: '#f0f0f0', borderRadius: 10, fontWeight: 700, fontSize: 13, textDecoration: 'none' }}>
                      🐙 GitHub
                    </a>
                  )}
                  <button onClick={() => setTab('preview')} style={{
                    padding: '12px 24px', background: 'rgba(255,255,255,0.06)',
                    border: '1px solid rgba(255,255,255,0.1)',
                    color: '#f0f0f0', borderRadius: 10, fontWeight: 700, fontSize: 13, cursor: 'pointer' }}>
                    📄 Ver Código
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB: PREVIEW */}
        {tab === 'preview' && (
          <div>
            {code ? (
              <>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
                  <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1, textTransform: 'uppercase',
                    color: 'rgba(240,240,240,0.45)' }}>Código Gerado (index.html)</span>
                  <button onClick={copyCode} style={{
                    padding: '6px 14px', background: 'rgba(255,255,255,0.04)',
                    border: '1px solid rgba(255,255,255,0.08)', borderRadius: 8,
                    color: 'rgba(240,240,240,0.45)', fontSize: 11, fontWeight: 600, cursor: 'pointer' }}>
                    📋 Copiar tudo
                  </button>
                </div>
                <pre style={{ background: '#000', border: '1px solid rgba(255,255,255,0.08)',
                  borderRadius: 10, padding: 16, fontFamily: 'monospace', fontSize: 10,
                  color: '#a0e0ff', maxHeight: 480, overflow: 'auto', whiteSpace: 'pre-wrap',
                  wordBreak: 'break-all', lineHeight: 1.5 }}>
                  {code}
                </pre>
              </>
            ) : (
              <div style={{ textAlign: 'center', padding: '60px 20px',
                color: 'rgba(240,240,240,0.35)', fontSize: 13 }}>
                <div style={{ fontSize: 40, marginBottom: 12 }}>🖥</div>
                Gere uma landing page para ver o código aqui
              </div>
            )}
          </div>
        )}

        {/* Footer */}
        <footer style={{ textAlign: 'center', padding: '32px 0 24px',
          color: 'rgba(255,255,255,0.2)', fontSize: 11,
          borderTop: '1px solid rgba(255,255,255,0.08)', marginTop: 48, letterSpacing: 0.5 }}>
          GENIX Elite Studio — Powered by Claude Sonnet · GitHub · Vercel
        </footer>
      </div>
    </div>
  )
}

const inputStyle: React.CSSProperties = {
  background: '#0d0d0d', border: '1px solid rgba(255,255,255,0.08)',
  borderRadius: 10, padding: '10px 14px', color: '#f0f0f0',
  fontSize: 13, outline: 'none', width: '100%',
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <label style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1,
        textTransform: 'uppercase', color: 'rgba(240,240,240,0.45)' }}>
        {label}
      </label>
      {children}
    </div>
  )
}

function Toggle({ label, sub, on, toggle }: { label: string; sub: string; on: boolean; toggle: () => void }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '10px 0', borderBottom: '1px solid rgba(255,255,255,0.06)', marginBottom: 10 }}>
      <div>
        <div style={{ fontSize: 12, color: '#f0f0f0' }}>{label}</div>
        <div style={{ fontSize: 11, color: 'rgba(240,240,240,0.4)' }}>{sub}</div>
      </div>
      <button onClick={toggle} style={{
        width: 40, height: 22, background: on ? '#7c6dfa' : 'rgba(255,255,255,0.1)',
        borderRadius: 100, border: 'none', position: 'relative', cursor: 'pointer',
        transition: 'background 0.2s', flexShrink: 0
      }}>
        <div style={{
          position: 'absolute', top: 3, left: on ? 21 : 3, width: 16, height: 16,
          background: '#fff', borderRadius: '50%', transition: 'left 0.2s'
        }} />
      </button>
    </div>
  )
}
