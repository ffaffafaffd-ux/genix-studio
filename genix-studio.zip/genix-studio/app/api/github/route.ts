import { NextRequest, NextResponse } from 'next/server'

export const runtime = 'edge'

export async function POST(req: NextRequest) {
  const { nome, code } = await req.json()

  const token = process.env.GITHUB_TOKEN
  const username = process.env.GITHUB_USERNAME

  if (!token || !username) {
    return NextResponse.json({ error: 'GitHub não configurado no servidor.' }, { status: 500 })
  }

  const repoName =
    'landing-' +
    nome.toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-').slice(0, 30) +
    '-' +
    Date.now().toString(36)

  // Create repo
  const createRes = await fetch('https://api.github.com/user/repos', {
    method: 'POST',
    headers: {
      Authorization: `token ${token}`,
      'Content-Type': 'application/json',
      Accept: 'application/vnd.github+json',
    },
    body: JSON.stringify({
      name: repoName,
      description: `Landing Page gerada por GENIX AI — ${nome}`,
      private: false,
      auto_init: false,
    }),
  })

  if (!createRes.ok) {
    const err = await createRes.json().catch(() => ({}))
    return NextResponse.json({ error: (err as any).message || 'Erro ao criar repositório' }, { status: 400 })
  }

  const repo = await createRes.json()
  const fullName = repo.full_name as string

  // Push index.html
  const content = Buffer.from(code).toString('base64')
  const pushRes = await fetch(`https://api.github.com/repos/${fullName}/contents/index.html`, {
    method: 'PUT',
    headers: {
      Authorization: `token ${token}`,
      'Content-Type': 'application/json',
      Accept: 'application/vnd.github+json',
    },
    body: JSON.stringify({
      message: 'feat: landing page gerada por GENIX AI',
      content,
    }),
  })

  if (!pushRes.ok) {
    const err = await pushRes.json().catch(() => ({}))
    return NextResponse.json({ error: (err as any).message || 'Erro ao push do arquivo' }, { status: 400 })
  }

  return NextResponse.json({
    repoUrl: repo.html_url,
    fullName,
    repoName,
  })
}
