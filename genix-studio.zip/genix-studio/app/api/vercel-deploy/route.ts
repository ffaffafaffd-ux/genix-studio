import { NextRequest, NextResponse } from 'next/server'

export const runtime = 'edge'

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms))
}

export async function POST(req: NextRequest) {
  const { nome, code } = await req.json()

  const token = process.env.VERCEL_TOKEN
  if (!token) {
    return NextResponse.json({ error: 'VERCEL_TOKEN não configurado no servidor.' }, { status: 500 })
  }

  const projectName =
    'genix-' +
    nome.toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-').slice(0, 28)

  // Deploy
  const deployRes = await fetch('https://api.vercel.com/v13/deployments', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      name: projectName,
      files: [
        { file: 'index.html', data: code },
        { file: 'package.json', data: JSON.stringify({ name: projectName, version: '1.0.0' }) },
      ],
      projectSettings: { framework: null },
      target: 'production',
    }),
  })

  if (!deployRes.ok) {
    const err = await deployRes.json().catch(() => ({}))
    return NextResponse.json(
      { error: (err as any).error?.message || 'Erro ao criar deploy na Vercel' },
      { status: 400 }
    )
  }

  const deploy = await deployRes.json()
  const deployId = deploy.id as string

  // Poll until ready (max ~90s)
  let vercelUrl = ''
  for (let i = 0; i < 30; i++) {
    await sleep(3000)
    const poll = await fetch(`https://api.vercel.com/v13/deployments/${deployId}`, {
      headers: { Authorization: `Bearer ${token}` },
    })
    if (poll.ok) {
      const d = await poll.json()
      const state = d.readyState || d.status
      if (state === 'READY') {
        vercelUrl = `https://${d.url || deploy.url}`
        break
      }
      if (state === 'ERROR' || state === 'CANCELED') {
        return NextResponse.json({ error: 'Deploy falhou na Vercel.' }, { status: 500 })
      }
    }
  }

  if (!vercelUrl && deploy.url) vercelUrl = `https://${deploy.url}`

  return NextResponse.json({ vercelUrl, deployId })
}
