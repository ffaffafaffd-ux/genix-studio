import { NextRequest, NextResponse } from 'next/server'

export const runtime = 'edge'

export async function POST(req: NextRequest) {
  const body = await req.json()
  const { nome, nicho, diferencial, servicos, depoimento, whatsapp, estilo, cor } = body

  if (!nome || !nicho || !diferencial) {
    return NextResponse.json({ error: 'Campos obrigatórios ausentes.' }, { status: 400 })
  }

  const apiKey = process.env.ANTHROPIC_API_KEY
  if (!apiKey) {
    return NextResponse.json({ error: 'ANTHROPIC_API_KEY não configurada no servidor.' }, { status: 500 })
  }

  const prompt = `Você é um web designer premiado pelo Awwwards e Diretor de Arte Digital de elite. Crie uma landing page HTML5 completa, cinematográfica e auto-contida (tudo em um único arquivo HTML com CSS e JS inline, SEM dependências externas).

DADOS DO CLIENTE:
- Nome/Empresa: ${nome}
- Nicho: ${nicho}
- Diferencial: ${diferencial}
- Serviços: ${servicos || 'Não especificado'}
- Depoimento: ${depoimento || 'Transformou meu negócio! Resultado incrível. — Cliente Satisfeito'}
- WhatsApp: ${whatsapp || '#'}
- Estilo Visual: ${estilo}
- Cor de destaque principal: ${cor}

REQUISITOS TÉCNICOS OBRIGATÓRIOS:
1. HTML5 completo auto-contido (um arquivo .html, sem imports externos exceto Google Fonts via @import no CSS)
2. CSS moderno com variáveis, glassmorphism, gradientes mesh
3. JavaScript vanilla para animações (IntersectionObserver para reveal ao scroll, parallax no hero)
4. Fundo escuro profundo (#050505) com acentos na cor ${cor}
5. Tipografia impactante — use Google Fonts via @import css (ex: Syne, Playfair Display, Bebas Neue, etc)
6. Cursor customizado que segue o mouse com efeito glow da cor ${cor}
7. Partículas animadas ou grade sutil no fundo do hero

SEÇÕES OBRIGATÓRIAS (nesta ordem):
1. NAVBAR — sticky, glassmorphism (backdrop-filter: blur), logo "${nome}" + botão CTA
2. HERO — headline gigante (font-size: clamp(60px,12vw,140px)), animação de entrada, subtítulo com diferencial, CTA button com glow
3. DIFERENCIAIS — 3 cards com ícones SVG inline, glassmorphism, hover com border glow na cor ${cor}
4. SERVIÇOS — grid de cards com imagem/gradiente, hover scale + tilt sutil
5. DEPOIMENTO — quote estilizado com foto placeholder e estrelas
6. CTA FINAL — seção com fundo gradiente usando ${cor}, headline e botão grande
7. FOOTER — minimalista com redes sociais e copyright "${nome} © 2025"
8. WHATSAPP FLOAT — botão fixo canto inferior direito, verde #25D366, link: https://wa.me/${whatsapp.replace(/\D/g, '') || '5511999999999'}

EFEITOS OBRIGATÓRIOS:
- Reveal animation ao scroll (IntersectionObserver + classes CSS)
- Parallax no hero (scroll listener)
- Hover tilt nos cards de serviços (mouse move listener)
- Smooth scroll nos links da navbar
- Loading animation inicial (1.5s) com logo e barra de progresso

RETORNE APENAS o código HTML completo começando com <!DOCTYPE html> e terminando com </html>. Nenhum texto antes ou depois.`

  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 8000,
        messages: [{ role: 'user', content: prompt }],
      }),
    })

    if (!res.ok) {
      const err = await res.json().catch(() => ({}))
      return NextResponse.json(
        { error: `Claude API error: ${(err as any).error?.message || res.status}` },
        { status: res.status }
      )
    }

    const data = await res.json()
    let code: string = (data.content?.[0]?.text || '').trim()

    // Strip markdown fences if present
    const match = code.match(/```(?:html|tsx?|jsx?)?\n?([\s\S]+?)```/)
    if (match) code = match[1].trim()

    if (!code || code.length < 500) {
      return NextResponse.json({ error: 'Claude retornou conteúdo inválido.' }, { status: 500 })
    }

    return NextResponse.json({ code })
  } catch (e: any) {
    return NextResponse.json({ error: e.message || 'Erro interno' }, { status: 500 })
  }
}
