# GENIX Studio — AI Landing Page Generator

Gerador de landing pages cinematográficas usando Claude, GitHub e Vercel.

## 🚀 Deploy em 5 minutos

### Pré-requisitos
- Conta na [Vercel](https://vercel.com)
- Conta no [GitHub](https://github.com)
- API Key do [Claude](https://console.anthropic.com)

---

### Passo 1 — Fork / Upload no GitHub

1. Crie um repositório no GitHub (ex: `genix-studio`)
2. Faça upload de todos os arquivos desta pasta
3. Ou use o CLI: `git init && git add . && git commit -m "init" && git push`

---

### Passo 2 — Deploy na Vercel

1. Acesse [vercel.com/new](https://vercel.com/new)
2. Conecte seu repositório `genix-studio`
3. Em **Environment Variables**, adicione:

| Variável | Valor |
|----------|-------|
| `ANTHROPIC_API_KEY` | `sk-ant-api03-...` |
| `GITHUB_TOKEN` | `ghp_...` (permissão: repo) |
| `GITHUB_USERNAME` | `seu-usuario-github` |
| `VERCEL_TOKEN` | `seu-token-vercel` |

4. Clique em **Deploy** ✅

---

### Onde obter as chaves

- **Claude**: [console.anthropic.com](https://console.anthropic.com) → API Keys
- **GitHub Token**: [github.com/settings/tokens](https://github.com/settings/tokens) → New token (classic) → marcar `repo`
- **Vercel Token**: [vercel.com/account/tokens](https://vercel.com/account/tokens) → Create Token (Full Account)

---

### Desenvolvimento local

```bash
cp .env.example .env.local
# Edite .env.local com suas chaves

npm install
npm run dev
```

Acesse: http://localhost:3000

---

## 🛠 Stack

- **Next.js 14** (App Router)
- **Claude Sonnet** (geração de código)
- **GitHub API** (criação de repositório)
- **Vercel API** (deploy automático)
- **TypeScript** + CSS puro (sem dependências de UI)

## ⚡ Como funciona

1. Usuário preenche dados do cliente (nome, nicho, diferencial, cores)
2. Backend chama Claude → gera HTML cinematográfico completo
3. Backend chama GitHub API → cria repositório + push do código
4. Backend chama Vercel API → faz deploy e aguarda ficar online
5. Usuário recebe o link do site publicado 🎉
